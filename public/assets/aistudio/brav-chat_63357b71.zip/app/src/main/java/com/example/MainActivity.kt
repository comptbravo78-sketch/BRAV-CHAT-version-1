package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.CallRepository
import com.example.data.ChatRepository
import com.example.data.ContactSyncRepository
import com.example.data.UserRepository
import com.example.ui.MainApp
import com.example.ui.theme.BravChatTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val userRepository = UserRepository(applicationContext)
        val contactSyncRepository = ContactSyncRepository(userRepository)
        val chatRepository = ChatRepository(applicationContext)
        val callRepository = CallRepository(applicationContext)

        setContent {
            BravChatTheme {
                MainApp(
                    userRepository = userRepository,
                    contactSyncRepository = contactSyncRepository,
                    chatRepository = chatRepository,
                    callRepository = callRepository
                )
            }
        }
    }
}
