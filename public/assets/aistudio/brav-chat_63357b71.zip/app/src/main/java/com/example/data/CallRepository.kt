package com.example.data

import android.content.Context
import com.example.R
import com.example.model.Call
import com.example.model.User
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CallRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Utilisateur non connecté")
    }

    /**
     * Initiates an audio or video call with another BRAV Chat user
     */
    suspend fun startCall(
        callerUser: User,
        receiverUser: User,
        callType: String = "audio"
    ): Result<String> {
        return try {
            val myUid = requireUserId()
            val targetUid = receiverUser.userId
            require(targetUid.isNotBlank() && targetUid != myUid) {
                "Destinataire d'appel invalide"
            }

            val docRef = db.collection("calls").document()
            val payload = mapOf(
                "callerId" to myUid,
                "callerName" to callerUser.displayName,
                "receiverId" to targetUid,
                "receiverName" to receiverUser.displayName,
                "callType" to callType,
                "status" to "calling",
                "createdAt" to FieldValue.serverTimestamp()
            )

            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "calls")
            Result.failure(e)
        }
    }

    /**
     * Observes a call session in real-time
     */
    fun observeCall(callId: String): Flow<Call?> = flow {
        val path = "calls/$callId"
        try {
            db.collection("calls")
                .document(callId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) snapshot.toObject(Call::class.java) else null
                }
                .collect { emit(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            throw e
        }
    }

    /**
     * Receiver answers the call
     */
    suspend fun answerCall(callId: String): Result<Unit> {
        return try {
            val myUid = requireUserId()
            val docRef = db.collection("calls").document(callId)
            docRef.update(
                mapOf(
                    "status" to "accepted",
                    "answer" to "call_accepted"
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Ends or rejects a call
     */
    suspend fun endCall(callId: String, durationSeconds: Long = 0L): Result<Unit> {
        return try {
            val myUid = requireUserId()
            val docRef = db.collection("calls").document(callId)
            val snapshot = docRef.get().await()

            if (snapshot.exists()) {
                val callerId = snapshot.getString("callerId")
                val receiverId = snapshot.getString("receiverId")

                if (callerId == myUid) {
                    docRef.update(
                        mapOf(
                            "status" to "ended",
                            "durationSeconds" to durationSeconds,
                            "endedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } else if (receiverId == myUid) {
                    docRef.update(
                        mapOf(
                            "status" to "ended",
                            "endedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
