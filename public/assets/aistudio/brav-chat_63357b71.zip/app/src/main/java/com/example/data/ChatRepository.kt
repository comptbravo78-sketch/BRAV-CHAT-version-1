package com.example.data

import android.content.Context
import com.example.R
import com.example.model.Conversation
import com.example.model.Message
import com.example.model.User
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Utilisateur non connecté")
    }

    /**
     * Derives a deterministic conversation ID for 2 participants to avoid duplicates
     */
    fun getConversationIdForParticipants(uid1: String, uid2: String): String {
        val sorted = listOf(uid1, uid2).sorted()
        return "conv_${sorted[0]}_${sorted[1]}"
    }

    /**
     * Gets or creates a 2-participant conversation between current user and another BRAV Chat user
     */
    suspend fun getOrCreateConversation(
        currentUser: User,
        targetUser: User
    ): Result<String> {
        return try {
            val myUid = requireUserId()
            val targetUid = targetUser.userId
            require(targetUid.isNotBlank() && targetUid != myUid) {
                "Le destinataire doit être un utilisateur différent"
            }

            val conversationId = getConversationIdForParticipants(myUid, targetUid)
            val docRef = db.collection("conversations").document(conversationId)
            val snapshot = docRef.get().await()

            if (!snapshot.exists()) {
                val payload = mapOf(
                    "participants" to listOf(myUid, targetUid),
                    "participantNames" to mapOf(
                        myUid to currentUser.displayName,
                        targetUid to targetUser.displayName
                    ),
                    "participantPhones" to mapOf(
                        myUid to currentUser.phoneNumber,
                        targetUid to targetUser.phoneNumber
                    ),
                    "participantLocations" to mapOf(
                        myUid to currentUser.locationCity,
                        targetUid to targetUser.locationCity
                    ),
                    "lastMessage" to "Conversation créée",
                    "lastMessageSenderId" to myUid,
                    "lastMessageType" to "text",
                    "lastMessageTimestamp" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "typingUsers" to emptyList<String>()
                )
                docRef.set(payload).await()
            }
            Result.success(conversationId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "conversations")
            Result.failure(e)
        }
    }

    /**
     * Observes all conversations where the current user is a participant
     */
    fun observeUserConversations(): Flow<List<Conversation>> = flow {
        val uid = requireUserId()
        val path = "conversations"

        try {
            db.collection("conversations")
                .whereArrayContains("participants", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Conversation::class.java)
                        .sortedByDescending { it.updatedAt?.toDate()?.time ?: 0L }
                }
                .collect { emit(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    /**
     * Observes real-time messages in a specific conversation
     */
    fun observeMessages(conversationId: String): Flow<List<Message>> = flow {
        val path = "conversations/$conversationId/messages"
        try {
            db.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Message::class.java)
                }
                .collect { emit(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    /**
     * Sends a new message in the conversation and updates parent conversation lastMessage
     */
    suspend fun sendMessage(
        conversationId: String,
        receiverId: String,
        content: String
    ): Result<String> {
        return try {
            val myUid = requireUserId()
            require(content.isNotBlank()) { "Le message ne peut être vide" }
            require(receiverId != myUid) { "Impossible de s'envoyer un message à soi-même" }

            val messageRef = db.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .document()

            val messagePayload = mapOf(
                "conversationId" to conversationId,
                "senderId" to myUid,
                "receiverId" to receiverId,
                "content" to content.trim(),
                "messageType" to "text",
                "status" to "sent",
                "timestamp" to FieldValue.serverTimestamp()
            )

            // 1. Create message in subcollection
            messageRef.set(messagePayload).await()

            // 2. Update conversation header
            val convRef = db.collection("conversations").document(conversationId)
            val updatePayload = mapOf(
                "lastMessage" to content.trim(),
                "lastMessageSenderId" to myUid,
                "lastMessageType" to "text",
                "lastMessageTimestamp" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            convRef.update(updatePayload).await()

            Result.success(messageRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "conversations/$conversationId/messages")
            Result.failure(e)
        }
    }

    /**
     * Marks a message as read by receiver
     */
    suspend fun markMessageAsRead(conversationId: String, messageId: String): Result<Unit> {
        return try {
            val myUid = requireUserId()
            val msgRef = db.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .document(messageId)

            val snapshot = msgRef.get().await()
            if (snapshot.exists() && snapshot.getString("receiverId") == myUid) {
                msgRef.update(
                    mapOf(
                        "status" to "read",
                        "readAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
