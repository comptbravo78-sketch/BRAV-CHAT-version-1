package com.example.data

import android.content.Context
import com.example.R
import com.example.model.User
import com.example.util.OperationType
import com.example.util.PhoneUtils
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("L'utilisateur doit être connecté pour accéder à BRAV Chat.")
    }

    private fun requireUserEmail(): String {
        return auth.currentUser?.email
            ?: throw IllegalStateException("Email utilisateur requis.")
    }

    /**
     * Observes current user profile document
     */
    fun observeCurrentUser(): Flow<User?> = flow {
        val uid = requireUserId()
        val path = "users/$uid"
        val docRef = db.collection("users").document(uid)

        try {
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(User::class.java)
                    } else {
                        null
                    }
                }
                .collect { emit(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            throw e
        }
    }

    /**
     * Observes all registered users on BRAV Chat to allow contact matching
     */
    fun observeAllBravUsers(): Flow<List<User>> = flow {
        val path = "users"
        try {
            db.collection("users")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(User::class.java)
                }
                .collect { emit(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    /**
     * Saves or updates the current user profile.
     * Complies strictly with Firestore rules:
     * - create requires role == 'user' and email == request.auth.token.email
     * - update requires email == resource.data.email
     */
    suspend fun saveUserProfile(
        displayName: String,
        phoneNumber: String,
        locationCity: String,
        locationDetails: String,
        bio: String = "Disponible sur BRAV Chat",
        role: String = "user"
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            val email = requireUserEmail()
            val normPhone = PhoneUtils.normalize(phoneNumber)
            val docRef = db.collection("users").document(uid)
            val snapshot = docRef.get().await()

            if (!snapshot.exists()) {
                // Creation
                val payload = mapOf(
                    "userId" to uid,
                    "email" to email,
                    "displayName" to displayName.trim(),
                    "phoneNumber" to normPhone,
                    "role" to "user",
                    "locationCity" to locationCity.trim(),
                    "locationDetails" to locationDetails.trim(),
                    "bio" to bio.trim(),
                    "avatarUrl" to "",
                    "isOnline" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                // Update
                val existingEmail = snapshot.getString("email") ?: email
                val existingRole = snapshot.getString("role") ?: "user"
                val payload = mapOf(
                    "userId" to uid,
                    "email" to existingEmail,
                    "displayName" to displayName.trim(),
                    "phoneNumber" to normPhone,
                    "role" to existingRole,
                    "locationCity" to locationCity.trim(),
                    "locationDetails" to locationDetails.trim(),
                    "bio" to bio.trim(),
                    "isOnline" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/${auth.currentUser?.uid}")
            Result.failure(e)
        }
    }

    /**
     * Helper to seed demo BRAV Chat users for demonstration/testing
     * (especially useful when running on an emulator without physical phone contacts)
     */
    suspend fun seedDemoContactsIfEmpty(): Result<Unit> {
        return try {
            // Check if demo users already exist
            val query = db.collection("users").limit(4).get().await()
            if (query.size() <= 1) {
                // We add sample verified contacts across Côte d'Ivoire with locations
                val demoUsers = listOf(
                    mapOf(
                        "userId" to "demo_koffi_001",
                        "email" to "koffi.jean@bravchat.ci",
                        "displayName" to "Koffi Jean",
                        "phoneNumber" to "+2250701020304",
                        "role" to "user",
                        "locationCity" to "Abidjan, Cocody",
                        "locationDetails" to "Angré 8ème Tranche",
                        "bio" to "Disponible pour échange professionnel",
                        "isOnline" to true
                    ),
                    mapOf(
                        "userId" to "demo_fatou_002",
                        "email" to "fatou.bamba@bravchat.ci",
                        "displayName" to "Fatou Bamba",
                        "phoneNumber" to "+2250505060708",
                        "role" to "provider",
                        "locationCity" to "Bouaké",
                        "locationDetails" to "Quartier Air France",
                        "bio" to "Prestataire certifiée BRAV - Décoration & Mode",
                        "isOnline" to true
                    ),
                    mapOf(
                        "userId" to "demo_kouame_003",
                        "email" to "kouame.patrick@bravchat.ci",
                        "displayName" to "Patrick Kouamé",
                        "phoneNumber" to "+2250102030405",
                        "role" to "user",
                        "locationCity" to "Yamoussoukro",
                        "locationDetails" to "Morofé / Village artisanal",
                        "bio" to "Toujours connecté sur BRAV Chat",
                        "isOnline" to false
                    ),
                    mapOf(
                        "userId" to "demo_amina_004",
                        "email" to "amina.traore@bravchat.ci",
                        "displayName" to "Amina Traoré",
                        "phoneNumber" to "+2250748596071",
                        "role" to "user",
                        "locationCity" to "San-Pédro",
                        "locationDetails" to "Balmer / Cité Portuaire",
                        "bio" to "Contactez-moi par message ou appel vocal",
                        "isOnline" to true
                    )
                )

                for (demo in demoUsers) {
                    val uid = demo["userId"] as String
                    val docRef = db.collection("users").document(uid)
                    val exists = docRef.get().await().exists()
                    if (!exists) {
                        val payload: MutableMap<String, Any> = HashMap(demo)
                        payload["createdAt"] = FieldValue.serverTimestamp()
                        payload["updatedAt"] = FieldValue.serverTimestamp()
                        docRef.set(payload).await()
                    }
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
