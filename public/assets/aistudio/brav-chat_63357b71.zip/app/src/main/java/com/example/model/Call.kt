package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Call(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val callType: String = "audio", // "audio" or "video"
    val status: String = "calling", // "calling", "accepted", "rejected", "ended"
    val answer: String = "",
    val callerCandidate: String = "",
    val receiverCandidate: String = "",
    val durationSeconds: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    val endedAt: Timestamp? = null
)
