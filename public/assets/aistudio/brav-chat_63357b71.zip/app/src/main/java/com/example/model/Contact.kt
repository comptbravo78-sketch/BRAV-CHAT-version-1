package com.example.model

data class Contact(
    val id: String = "",
    val phoneDisplayName: String = "",
    val rawPhoneNumber: String = "",
    val normalizedPhoneNumber: String = "",
    val bravUser: User? = null
) {
    val isBravUser: Boolean get() = bravUser != null

    val displayLocation: String
        get() {
            val user = bravUser ?: return ""
            return when {
                user.locationCity.isNotBlank() && user.locationDetails.isNotBlank() ->
                    "${user.locationCity} (${user.locationDetails})"
                user.locationCity.isNotBlank() -> user.locationCity
                user.locationDetails.isNotBlank() -> user.locationDetails
                else -> "Localisation non précisée"
            }
        }

    val preferredDisplayName: String
        get() = when {
            phoneDisplayName.isNotBlank() -> phoneDisplayName
            bravUser?.displayName?.isNotBlank() == true -> bravUser.displayName
            else -> normalizedPhoneNumber
        }
}
