package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class User(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val phoneNumber: String = "",
    val role: String = "user", // "user" or "provider"
    val locationCity: String = "", // e.g. "Abidjan, Cocody", "Bouaké", "Yamoussoukro"
    val locationDetails: String = "", // quartier, village ou commune
    val avatarUrl: String = "",
    val bio: String = "Disponible sur BRAV Chat",
    val isOnline: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
