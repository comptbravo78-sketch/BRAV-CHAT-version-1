package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.CallRepository
import com.example.data.ChatRepository
import com.example.data.ContactSyncRepository
import com.example.data.UserRepository
import com.example.model.User
import com.example.ui.auth.SignInScreen
import com.example.ui.auth.signOutUser
import com.example.ui.call.CallScreen
import com.example.ui.chat.ChatConversationScreen
import com.example.ui.chat.ChatListScreen
import com.example.ui.contacts.ContactsScreen
import com.example.ui.profile.ProfileSetupDialog
import com.example.util.PhoneUtils
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    userRepository: UserRepository,
    contactSyncRepository: ContactSyncRepository,
    chatRepository: ChatRepository,
    callRepository: CallRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUserAuth by remember { mutableStateOf(Firebase.auth.currentUser) }

    // Auth state listener
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUserAuth = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    if (currentUserAuth == null) {
        SignInScreen(
            onAuthSuccess = {
                currentUserAuth = Firebase.auth.currentUser
            }
        )
    } else {
        val uid = currentUserAuth!!.uid

        // Observe user profile
        val userProfile by userRepository.observeCurrentUser()
            .collectAsState(initial = null)

        // Observe all BRAV users for directory matching
        val allBravUsers by userRepository.observeAllBravUsers()
            .collectAsState(initial = emptyList())

        // Observe user conversations
        val conversations by chatRepository.observeUserConversations()
            .collectAsState(initial = emptyList())

        var selectedTab by remember { mutableIntStateOf(0) } // 0: Contacts, 1: Discussions, 2: Mon Profil
        var showProfileDialog by remember { mutableStateOf(false) }

        // Navigation state for sub-screens
        var activeConversation by remember { mutableStateOf<Pair<String, User>?>(null) } // convId, otherUser
        var activeCall by remember { mutableStateOf<Triple<String, User, String>?>(null) } // callId, otherUser, type

        // Automatically prompt profile & location setup if not yet configured
        LaunchedEffect(userProfile) {
            if (userProfile == null || userProfile?.phoneNumber.isNullOrBlank() || userProfile?.locationCity.isNullOrBlank()) {
                showProfileDialog = true
            }
            // Seed demo contacts so user immediately sees contacts in Ivory Coast
            userRepository.seedDemoContactsIfEmpty()
        }

        // Active Call Screen Overlay
        if (activeCall != null) {
            val (callId, targetUser, callType) = activeCall!!
            BackHandler {
                activeCall = null
            }
            CallScreen(
                callId = callId,
                targetUser = targetUser,
                callType = callType,
                callRepository = callRepository,
                onCallEnded = {
                    activeCall = null
                }
            )
            return
        }

        // Active Chat Conversation Screen
        if (activeConversation != null) {
            val (conversationId, targetUser) = activeConversation!!
            BackHandler {
                activeConversation = null
            }
            val profileToPass = userProfile ?: User(
                userId = uid,
                email = currentUserAuth?.email ?: "",
                displayName = currentUserAuth?.displayName ?: "Moi"
            )

            ChatConversationScreen(
                conversationId = conversationId,
                targetUser = targetUser,
                currentUser = profileToPass,
                chatRepository = chatRepository,
                onBack = { activeConversation = null },
                onStartCall = { user, type ->
                    scope.launch {
                        val result = callRepository.startCall(profileToPass, user, type)
                        if (result.isSuccess) {
                            activeCall = Triple(result.getOrThrow(), user, type)
                        }
                    }
                }
            )
            return
        }

        // Profile Setup / Location Dialog
        if (showProfileDialog) {
            ProfileSetupDialog(
                currentUser = userProfile,
                userRepository = userRepository,
                onDismiss = { showProfileDialog = false },
                onSaved = { showProfileDialog = false }
            )
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Card(
                                modifier = Modifier.size(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_brav_logo),
                                        contentDescription = "Logo BRAV Chat",
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "BRAV Chat",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                                )
                                Text(
                                    text = "Mise en relation sécurisée",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showProfileDialog = true },
                            modifier = Modifier.testTag("open_profile_setup_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Ma localisation",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Contacts, contentDescription = "Contacts") },
                        label = { Text("Contacts BRAV") },
                        modifier = Modifier.testTag("tab_contacts")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Discussions") },
                        label = { Text("Discussions") },
                        modifier = Modifier.testTag("tab_chats")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Mon Profil") },
                        label = { Text("Ma Position") },
                        modifier = Modifier.testTag("tab_profile")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    0 -> ContactsScreen(
                        currentUser = userProfile,
                        userRepository = userRepository,
                        contactSyncRepository = contactSyncRepository,
                        allBravUsers = allBravUsers,
                        onStartChat = { targetUser ->
                            val myUser = userProfile ?: User(
                                userId = uid,
                                email = currentUserAuth?.email ?: "",
                                displayName = currentUserAuth?.displayName ?: "Moi"
                            )
                            scope.launch {
                                val convResult = chatRepository.getOrCreateConversation(myUser, targetUser)
                                if (convResult.isSuccess) {
                                    activeConversation = Pair(convResult.getOrThrow(), targetUser)
                                }
                            }
                        },
                        onStartCall = { targetUser, type ->
                            val myUser = userProfile ?: User(
                                userId = uid,
                                email = currentUserAuth?.email ?: "",
                                displayName = currentUserAuth?.displayName ?: "Moi"
                            )
                            scope.launch {
                                val result = callRepository.startCall(myUser, targetUser, type)
                                if (result.isSuccess) {
                                    activeCall = Triple(result.getOrThrow(), targetUser, type)
                                }
                            }
                        },
                        onOpenProfileSetup = { showProfileDialog = true }
                    )

                    1 -> ChatListScreen(
                        conversations = conversations,
                        allBravUsers = allBravUsers,
                        currentUser = userProfile ?: User(userId = uid),
                        onOpenConversation = { conv, otherUser ->
                            activeConversation = Pair(conv.id, otherUser)
                        }
                    )

                    2 -> ProfileTabScreen(
                        currentUser = userProfile,
                        userAuthEmail = currentUserAuth?.email ?: "",
                        onEditProfile = { showProfileDialog = true },
                        onSignOut = {
                            signOutUser(
                                credentialManager = credentialManager,
                                scope = scope,
                                onSignOutComplete = { currentUserAuth = null }
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileTabScreen(
    currentUser: User?,
    userAuthEmail: String,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Avatar
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                val initial = currentUser?.displayName?.firstOrNull()?.uppercase() ?: "B"
                Text(
                    text = initial,
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = currentUser?.displayName?.ifEmpty { "Utilisateur BRAV" } ?: "Utilisateur BRAV",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = userAuthEmail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Location Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ma Localisation Déclarée",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        IconButton(onClick = onEditProfile) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Modifier",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Ville ou Village : ${currentUser?.locationCity.takeIf { !it.isNullOrBlank() } ?: "Non renseigné"}",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Quartier / Précision : ${currentUser?.locationDetails.takeIf { !it.isNullOrBlank() } ?: "Non renseigné"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Cette localisation est visible sous votre nom par vos contacts dans l'application BRAV Chat peu importe où vous vous déplacez.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Phone Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Numéro de téléphone",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = PhoneUtils.formatDisplay(currentUser?.phoneNumber ?: "Non configuré"),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Logout Button
            Button(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("logout_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Se déconnecter", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
