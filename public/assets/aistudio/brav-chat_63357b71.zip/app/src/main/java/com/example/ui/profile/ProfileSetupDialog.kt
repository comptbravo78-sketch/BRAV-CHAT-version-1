package com.example.ui.profile

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.UserRepository
import com.example.model.User
import kotlinx.coroutines.launch

@Composable
fun ProfileSetupDialog(
    currentUser: User?,
    userRepository: UserRepository,
    onDismiss: () -> Unit,
    onSaved: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var displayName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var phoneNumber by remember { mutableStateOf(currentUser?.phoneNumber ?: "+225") }
    var locationCity by remember { mutableStateOf(currentUser?.locationCity ?: "Abidjan, Cocody") }
    var locationDetails by remember { mutableStateOf(currentUser?.locationDetails ?: "Quartier Angré") }
    var bio by remember { mutableStateOf(currentUser?.bio ?: "Disponible sur BRAV Chat") }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var cityDropdownExpanded by remember { mutableStateOf(false) }

    val popularCities = listOf(
        "Abidjan, Cocody",
        "Abidjan, Yopougon",
        "Abidjan, Plateau",
        "Abidjan, Marcory",
        "Abidjan, Port-Bouët",
        "Bouaké",
        "Yamoussoukro",
        "San-Pédro",
        "Korhogo",
        "Daloa",
        "Man",
        "Gagnoa"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Mon Profil & Ma Position",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Indiquez votre numéro pour que vos contacts puissent vous trouver, et votre position actuelle (ville, quartier, village).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Nom complet
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Nom ou Pseudo") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Numéro de téléphone
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text("Numéro de Téléphone (ex: +2250701020304)") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_phone_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Ville / Commune / Village
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = locationCity,
                        onValueChange = { locationCity = it },
                        label = { Text("Ville ou Village principal") },
                        leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null) },
                        trailingIcon = {
                            Text(
                                text = "Choix ▼",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { cityDropdownExpanded = true }
                                    .padding(8.dp)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_city_input"),
                        singleLine = true
                    )

                    DropdownMenu(
                        expanded = cityDropdownExpanded,
                        onDismissRequest = { cityDropdownExpanded = false }
                    ) {
                        popularCities.forEach { city ->
                            DropdownMenuItem(
                                text = { Text(city) },
                                onClick = {
                                    locationCity = city
                                    cityDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quartier / Village précis
                OutlinedTextField(
                    value = locationDetails,
                    onValueChange = { locationDetails = it },
                    label = { Text("Quartier ou Village précis (ex: Angré, Morofé)") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_details_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Bio / Statut
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("Statut / Bio") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (displayName.isBlank()) {
                        errorMessage = "Veuillez renseigner votre nom"
                        return@Button
                    }
                    if (phoneNumber.isBlank() || phoneNumber == "+225") {
                        errorMessage = "Veuillez renseigner un numéro de téléphone"
                        return@Button
                    }
                    if (locationCity.isBlank()) {
                        errorMessage = "Veuillez indiquer votre ville ou village"
                        return@Button
                    }

                    isSaving = true
                    errorMessage = null
                    scope.launch {
                        val result = userRepository.saveUserProfile(
                            displayName = displayName,
                            phoneNumber = phoneNumber,
                            locationCity = locationCity,
                            locationDetails = locationDetails,
                            bio = bio
                        )
                        isSaving = false
                        if (result.isSuccess) {
                            onSaved()
                        } else {
                            errorMessage = result.exceptionOrNull()?.localizedMessage
                                ?: "Erreur d'enregistrement"
                        }
                    }
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_profile_button")
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.height(20.dp)
                    )
                } else {
                    Text("Enregistrer")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}
