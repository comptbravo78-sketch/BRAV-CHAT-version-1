package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official BRAV Chat Brand Colors from Logo
val BravPurplePrimary = Color(0xFF570CA2)
val BravPurplePrimaryDark = Color(0xFF8B3CD3)
val BravRedSecondary = Color(0xFFEA0D1B)
val BravRedSecondaryDark = Color(0xFFFF5252)

// Light Scheme Colors
val PrimaryLight = Color(0xFF570CA2)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFF3E8FF)
val OnPrimaryContainerLight = Color(0xFF2E0061)

val SecondaryLight = Color(0xFFEA0D1B)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFE4E6)
val OnSecondaryContainerLight = Color(0xFF6B0007)

val TertiaryLight = Color(0xFF047857) // Location accent green
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFD1FAE5)
val OnTertiaryContainerLight = Color(0xFF064E3B)

val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateOnSurfaceLight = Color(0xFF0F172A)
val SlateOnSurfaceVariantLight = Color(0xFF475569)

// Dark Scheme Colors
val PrimaryDark = Color(0xFFA855F7)
val OnPrimaryDark = Color(0xFF2E0061)
val PrimaryContainerDark = Color(0xFF4C0B8E)
val OnPrimaryContainerDark = Color(0xFFF3E8FF)

val SecondaryDark = Color(0xFFFF6B6B)
val OnSecondaryDark = Color(0xFF4D0004)
val SecondaryContainerDark = Color(0xFF8B000B)
val OnSecondaryContainerDark = Color(0xFFFFD8D8)

val TertiaryDark = Color(0xFF34D399)
val OnTertiaryDark = Color(0xFF064E3B)
val TertiaryContainerDark = Color(0xFF065F46)
val OnTertiaryContainerDark = Color(0xFFA7F3D0)

val SlateBackgroundDark = Color(0xFF0B0F19)
val SlateSurfaceDark = Color(0xFF161E2E)
val SlateSurfaceVariantDark = Color(0xFF232D42)
val SlateOnSurfaceDark = Color(0xFFF8FAFC)
val SlateOnSurfaceVariantDark = Color(0xFF94A3B8)

// Status colors
val OnlineGreen = Color(0xFF10B981)
val LocationPinColor = Color(0xFF059669) // Emerald green location badge
val CallActionGreen = Color(0xFF16A34A)
val EndCallRed = Color(0xFFDC2626)
