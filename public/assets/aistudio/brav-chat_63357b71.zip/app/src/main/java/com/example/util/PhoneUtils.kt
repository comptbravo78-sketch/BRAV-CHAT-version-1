package com.example.util

object PhoneUtils {
    /**
     * Normalizes a phone number by keeping only digits and leading '+'.
     * Handles local and international Côte d'Ivoire numbers (+225) as well as global numbers.
     */
    fun normalize(rawNumber: String): String {
        val trimmed = rawNumber.trim()
        if (trimmed.isBlank()) return ""

        val hasPlus = trimmed.startsWith("+")
        val digits = trimmed.filter { it.isDigit() }
        if (digits.isEmpty()) return ""

        return if (hasPlus) {
            "+$digits"
        } else {
            // If it starts with 00, treat as international +
            if (digits.startsWith("00") && digits.length > 2) {
                "+${digits.substring(2)}"
            } else if (digits.length == 10 && (digits.startsWith("07") || digits.startsWith("05") || digits.startsWith("01"))) {
                // Côte d'Ivoire 10-digit number e.g. 0701020304 -> canonical format
                "+225$digits"
            } else if (digits.length == 8 && (digits.startsWith("0") || digits.startsWith("4") || digits.startsWith("5") || digits.startsWith("7"))) {
                // Older 8-digit format in CI
                "+225$digits"
            } else {
                digits
            }
        }
    }

    /**
     * Checks if two phone numbers match, considering possible international prefixes (+225)
     * and local 10-digit formats.
     */
    fun matches(phoneA: String, phoneB: String): Boolean {
        val normA = normalize(phoneA)
        val normB = normalize(phoneB)

        if (normA.isEmpty() || normB.isEmpty()) return false
        if (normA == normB) return true

        val digitsA = normA.filter { it.isDigit() }
        val digitsB = normB.filter { it.isDigit() }

        if (digitsA == digitsB) return true

        // Match ending digits (at least 8 or 10 digits match)
        val minLen = minOf(digitsA.length, digitsB.length)
        if (minLen >= 8) {
            val suffixA = digitsA.takeLast(8)
            val suffixB = digitsB.takeLast(8)
            if (suffixA == suffixB) return true
        }

        return false
    }

    /**
     * Pretty formatting for display
     */
    fun formatDisplay(phoneNumber: String): String {
        val norm = normalize(phoneNumber)
        if (norm.startsWith("+225") && norm.length == 14) {
            // +225 07 01 02 03 04
            val prefix = norm.substring(0, 4)
            val operator = norm.substring(4, 6)
            val p1 = norm.substring(6, 8)
            val p2 = norm.substring(8, 10)
            val p3 = norm.substring(10, 12)
            val p4 = norm.substring(12, 14)
            return "$prefix $operator $p1 $p2 $p3 $p4"
        }
        return phoneNumber
    }
}
