package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.UserRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class UserRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveUserProfile_authenticatedUser_savesProfileSuccessfully() {
        runBlocking {
            signInTestUser(ALICE_EMAIL)
            val repository = UserRepository(firestore)

            val result = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.saveUserProfile(
                    displayName = "Alice Doe",
                    phoneNumber = "+2250700000001",
                    locationCity = "Abidjan, Cocody",
                    locationDetails = "Angré"
                )
            }
            assertTrue(result.isSuccess)
        }
    }

    @Test
    fun observeAllBravUsers_authenticatedUser_emitsUsers() {
        runBlocking {
            signInTestUser(ALICE_EMAIL)
            val repository = UserRepository(firestore)

            withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.saveUserProfile(
                    displayName = "Alice Doe",
                    phoneNumber = "+2250700000001",
                    locationCity = "Abidjan, Cocody",
                    locationDetails = "Angré"
                )
            }

            val users = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.observeAllBravUsers().first()
            }
            assertTrue(users.isNotEmpty())
        }
    }

    @Test
    fun observeAllBravUsers_unauthenticatedUser_failsWithPermissionDenied() {
        runBlocking {
            auth.signOut()
            val repository = UserRepository(firestore)

            try {
                withTimeout(DEFAULT_TIMEOUT_MS) {
                    repository.observeAllBravUsers().first()
                }
                fail("Expected permission denied exception")
            } catch (e: Exception) {
                val firestoreException = e.unwrapFirestoreException()
                assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
                assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
            }
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@bravchat.ci"
        const val DEFAULT_TIMEOUT_MS = 5000L
    }
}
